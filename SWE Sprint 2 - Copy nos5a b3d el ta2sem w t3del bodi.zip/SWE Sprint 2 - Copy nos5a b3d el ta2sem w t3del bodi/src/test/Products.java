package test;

import java.io.IOException;

public interface Products {
	public void addProduct() throws IOException;

}
