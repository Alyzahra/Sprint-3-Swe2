
/*public class FileModel {
	public void writeIntoFile(IEntity entity, File file) {
		if (entity.validateData()) {
			String info = entity.getPrintableInfo();
			file.write(info);
		}
	}
}
*/