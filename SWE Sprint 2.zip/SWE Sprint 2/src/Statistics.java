import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.TimerTask;

public class Statistics {
	static private int products_views=0 ;
	static private int stores_view=0;
	static private int sold_products=0;
	static private int orderd_brand=0;
	static private int sum = 0; 
	static private int view =0;
	private UsersStatistics Products_sold;

public int getOrderd_brand() {
	
	orderd_brand++;
		return orderd_brand;
	}

public int getProducts_views() {
	products_views++;
		return products_views;
	}

public int getStores_view() {
	stores_view++;
		return stores_view;
	}

public int getSold_products()  {
	
		return sold_products;
	}
public static int getView() {
	return view;
}

public static void setView(int view) {
	Statistics.view = view;
}


}

