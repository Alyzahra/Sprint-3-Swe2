import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Offers {
	
private int offer;

public int ProductName(String name) throws IOException {
		File file = new File("Offers.txt");
		BufferedReader br = new BufferedReader(new FileReader(file)); 
		String s = null ;
		
		while((s = br.readLine()) != null&(offer = br.read())!=0) {
		       
		            if(s.equals(name)){
		            	return offer;
		            }
		}
		return 0 ;
	}
		
public int Calculate_Offer(int x) throws IOException {
	x=ProductName(null);
	File file = new File("StoreProducts.txt");
	BufferedReader br = new BufferedReader(new FileReader(file));
	
	
	return x;
	
	
}

		
		
}