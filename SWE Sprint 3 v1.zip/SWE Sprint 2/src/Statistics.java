import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.TimerTask;

public class Statistics {
	static int products_views=0 ;
	static int stores_view=0;
	static int sold_products=0;
	static int orderd_brand=0;
	static int sum = 0; 
	static int view =0;

public int getOrderd_brand() {
	orderd_brand++;
		return orderd_brand;
	}

public int getProducts_views() {
	products_views++;
		return products_views;
	}

public int getStores_view() {
	stores_view++;
		return stores_view;
	}

public int getSold_products() {
	sold_products=sum;
		return sold_products;
	}
public static int getView() {
	return view;
}

public static void setView(int view) {
	Statistics.view = view;
}


}

