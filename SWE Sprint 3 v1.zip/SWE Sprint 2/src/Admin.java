import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import test.Products;

public class Admin implements Products {
	
	private String brandname;
	private String brandcategory;
	private Controller Admin_controller;
	private User Admin_log;
	private Products1 Add_product;

public String getBrandname() {
		return brandname;
	}

public void setBrandname(String brandname) {
		this.brandname = brandname;
	}

public String getBrandcategory() {
		return brandcategory;
	}

public void setBrandcategory(String brandcategory) {
		this.brandcategory = brandcategory;
	}
	
public void addbrands() throws IOException {
	File f = new File("AdminBrands");
	FileWriter h = new FileWriter(f, true);
	System.out.println("Enter Brand name");
	Scanner x = new Scanner(System.in);
	this.setBrandname(x.next());
	System.out.println("Enter Brand category");
	Scanner p = new Scanner(System.in);
	this.setBrandcategory(p.next());
	h.write(this.getBrandname());
	h.write("\n");
	h.write(this.getBrandcategory());
	h.write("\n");
	System.out.println("Brand Is Added Successfuly");
	h.close();
	
}

public void addProduct() throws IOException {
	// TODO Auto-generated method stub
	File f = new File("AdminProducts.txt");
	FileWriter h = new FileWriter(f, true);
	Products1 Add_product = new Products1();
	System.out.println("Enter name");
	Scanner x = new Scanner(System.in);
	Add_product.setName(x.next()); 
	System.out.println("Enter price");
	Scanner y = new Scanner(System.in);
	Add_product.setPrice(y.next());
	System.out.println("Enter Brand");
	Scanner u = new Scanner(System.in);
	Add_product.setBrand(u.next());
	System.out.println("Enter category");
	Scanner p = new Scanner(System.in);
	Add_product.setCategory(p.next()); 
	h.write(Add_product.getName());
	h.write("\n");
	h.write(Add_product.getPrice());
	h.write("\n");
	h.write(Add_product.getBrand());
	h.write("\n");
	h.write(Add_product.getCategory());
	h.write("\n");
	System.out.println("Product Is Added Successfuly");
	h.close();		
}

public boolean approveStore(String w) throws IOException {
	Controller Admin_controller = new Controller();
	return Admin_controller.VerifyStore(w);
}

public boolean approveProduct(String i ) throws IOException {
	Controller Admin_controller = new Controller();
	return Admin_controller.VerifyProduct(i);
}

public void Admin_login() throws IOException {
	User Admin_log = new User();
	Admin_log.login();
}//////////////////

///////////////
public int sum_users() throws IOException {
	File file = new File("SoldProducts.txt"); 
 
	BufferedReader br = new BufferedReader(new FileReader(file)); 
	String s0; 
	 String s1;
	 String s2;
	 String s3;
	 String s4;
	 int  sum_users=0;
	while((s0 = br.readLine()) != null&(s1 = br.readLine()) != null&(s2 = br.readLine()) != null &(s3 = br.readLine()) != null&(s4 = br.readLine()) != null) {
		sum_users++;
}
	return sum_users;
	

}////////////////////



public int avg_users() throws IOException {
	int sum = sum_users();
	return sum/2 ;
	
}


///////////////////
public String minproduct() throws IOException {
	File file = new File("SoldProducts.txt");  
	BufferedReader br = new BufferedReader(new FileReader(file)); 
	Map<String,Integer>x =new HashMap<String, Integer>();
	int i=0;
	String s0; 
	while((s0 = br.readLine()) != null) {
		if(i==1) {
		if(x.get(s0)!=null) {
			x.put(s0,x.get(s0)+1);
		}else {
			x.put(s0,1);
		}
		
		}	
		i++;

		if(i==5) {
			i=0;
		}
	}
	int minnum=100;
	String name = null;
	for(Map.Entry<String, Integer>entry:x.entrySet()) {
		if(entry.getValue()<minnum)
		{
			minnum=entry.getValue();
			name=entry.getKey();
		}}
	return name;
		}
/////////////////////
public String maxproduct() throws IOException {
	File file = new File("SoldProducts.txt");  
	BufferedReader br = new BufferedReader(new FileReader(file)); 
	Map<String,Integer>x =new HashMap<String, Integer>();
	int i=0;
	String s0; 
	while((s0 = br.readLine()) != null) {
		if(i==1) {
		if(x.get(s0)!=null) {
			x.put(s0,x.get(s0)+1);
		}else {
			x.put(s0,1);
		}
		}
		
		
		
		
		i++;
		if(i==5) {
			i=0;
		}
	}
	int maxnum=0;
	String name = null;
	for(Map.Entry<String, Integer>entry:x.entrySet()) {
		if(entry.getValue()>maxnum) {
			name=entry.getKey();
		}}
	return name;
		}
		
	
/////////////////
public String max() throws IOException {
	File file = new File("SoldProducts.txt");  
	BufferedReader br = new BufferedReader(new FileReader(file)); 
	Map<String,Integer>x =new HashMap<String, Integer>();
	int i=0;
	String s0; 
	while((s0 = br.readLine()) != null) {
		if(i==0) {
		if(x.get(s0)!=null) {
			x.put(s0,x.get(s0)+1);
		}else {
			x.put(s0,1);
		}
		}
		
		
		
		
		i++;
		if(i==5) {
			i=0;
		}
	}
	int maxnum=0;
	String name = null;
	for(Map.Entry<String, Integer>entry:x.entrySet()) {
		if(entry.getValue()>maxnum) {
			name=entry.getKey();
		}}
	return name;
		}
		
	

////////////////////
public String min() throws IOException {
	File file = new File("SoldProducts.txt");  
	BufferedReader br = new BufferedReader(new FileReader(file)); 
	Map<String,Integer>x =new HashMap<String, Integer>();
	int i=0;
	String s0; 
	while((s0 = br.readLine()) != null) {
		if(i==0) {
		if(x.get(s0)!=null) {
			x.put(s0,x.get(s0)+1);
		}else {
			x.put(s0,1);
		}
		
		}	
		i++;

		if(i==5) {
			i=0;
		}
	}
	int minnum=100;
	String name = null;
	for(Map.Entry<String, Integer>entry:x.entrySet()) {
		if(entry.getValue()<minnum)
		{
			minnum=entry.getValue();
			name=entry.getKey();
		}}
	return name;
		}
}

/*public Products search(String name) throws FileNotFoundException, IOException{ 
    int count = 1;
Integer intInstance = new Integer(count);      
String numberAsString = intInstance.toString();
   BufferedReader reader=new BufferedReader(new FileReader("F:\\College\\Software Engineering 2 project code\\SWE - copy"));
   String row=reader.readLine();
   while(row!=null){ 
   String[] fields=row.split(" ");
   String CurrentProduct=fields[0];
   if(name.equals(CurrentProduct)){
    System.out.println(row);
   }
   row=reader.readLine();
   }
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
LocalDateTime now = LocalDateTime.now(); 
   PrintWriter writer =new PrintWriter(new FileWriter("",true));
 String newRow=this.getName();
  newRow = newRow.concat(" ");
   newRow=newRow.concat(name);
   newRow = newRow.concat(" ");
   newRow=newRow.concat(dtf.format(now));
    newRow = newRow.concat(" ");
   newRow=newRow.concat(numberAsString);
   writer.println(newRow);
writer.close();
   return null;
}*/

